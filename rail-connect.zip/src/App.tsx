import { useState, useEffect, ReactNode } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Home, 
  Search, 
  User, 
  Bell, 
  MessageSquare, 
  Utensils, 
  Train as TrainIcon, 
  Map, 
  Clock, 
  ShieldAlert,
  ArrowLeft,
  ChevronRight,
  LogOut
} from 'lucide-react';
import { Role, Train, Ticket } from './types';
import { MOCK_TRAINS, MOCK_TICKETS } from './constants';

// Screen Components
import SplashScreen from './screens/SplashScreen';
import OnboardingScreen from './screens/OnboardingScreen';
import RoleSelectionScreen from './screens/RoleSelectionScreen';
import LoginScreen from './screens/LoginScreen';
import PassengerHome from './screens/PassengerHome';
import TrainDashboard from './screens/TrainDashboard';
import TicketsScreen from './screens/TicketsScreen';
import ServicesScreen from './screens/ServicesScreen';
import RailoChat from './screens/RailoChat';
import FoodOrder from './screens/FoodOrder';
import NotificationsScreen from './screens/NotificationsScreen';
import ProfileScreen from './screens/ProfileScreen';
import StationAlarm from './screens/StationAlarm';
import Tracking3D from './screens/Tracking3D';
import BookingScreen from './screens/BookingScreen';
import SeatSelection from './screens/SeatSelection';
import RefundScreen from './screens/RefundScreen';
import AttendantPanel from './screens/AttendantPanel';

export type Screen = 
  | 'splash' | 'onboarding' | 'roleSelection' | 'login' 
  | 'home' | 'trainDashboard' | 'tickets' | 'services' 
  | 'chat' | 'food' | 'notifications' | 'profile'
  | 'alarm' | 'tracking' | 'booking' | 'seats' | 'refund'
  | 'attendantPanel';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('splash');
  const [userRole, setUserRole] = useState<Role | null>(null);
  const [selectedTrain, setSelectedTrain] = useState<Train>(MOCK_TRAINS[0]);
  const [prevScreen, setPrevScreen] = useState<Screen | null>(null);

  const navigateTo = (screen: Screen) => {
    setPrevScreen(currentScreen);
    setCurrentScreen(screen);
  };

  const goBack = () => {
    if (prevScreen) {
      setCurrentScreen(prevScreen);
      setPrevScreen(null);
    } else {
      navigateTo('home');
    }
  };

  // Splash effect
  useEffect(() => {
    if (currentScreen === 'splash') {
      const timer = setTimeout(() => navigateTo('onboarding'), 2500);
      return () => clearTimeout(timer);
    }
  }, [currentScreen]);

  const renderScreen = () => {
    switch (currentScreen) {
      case 'splash': return <SplashScreen />;
      case 'onboarding': return <OnboardingScreen onNext={() => navigateTo('roleSelection')} />;
      case 'roleSelection': return (
        <RoleSelectionScreen 
          onSelect={(role) => {
            setUserRole(role);
            navigateTo('login');
          }} 
        />
      );
      case 'login': return (
        <LoginScreen 
          onLogin={() => navigateTo(userRole === 'attendant' ? 'attendantPanel' : 'home')} 
          goBack={() => navigateTo('roleSelection')}
        />
      );
      case 'home': return <PassengerHome navigate={navigateTo} />;
      case 'trainDashboard': return <TrainDashboard navigate={navigateTo} goBack={goBack} />;
      case 'tickets': return <TicketsScreen navigate={navigateTo} goBack={goBack} />;
      case 'services': return <ServicesScreen navigate={navigateTo} goBack={goBack} />;
      case 'chat': return <RailoChat goBack={goBack} />;
      case 'food': return <FoodOrder navigate={navigateTo} goBack={goBack} />;
      case 'notifications': return <NotificationsScreen goBack={goBack} />;
      case 'profile': return <ProfileScreen navigate={navigateTo} goBack={goBack} />;
      case 'alarm': return <StationAlarm goBack={goBack} />;
      case 'tracking': return <Tracking3D goBack={goBack} />;
      case 'booking': return <BookingScreen navigate={navigateTo} goBack={goBack} />;
      case 'seats': return <SeatSelection navigate={navigateTo} goBack={goBack} />;
      case 'refund': return <RefundScreen goBack={goBack} />;
      case 'attendantPanel': return <AttendantPanel goBack={() => navigateTo('login')} />;
      default: return <PassengerHome navigate={navigateTo} />;
    }
  };

  const showNavbar = !['splash', 'onboarding', 'roleSelection', 'login'].includes(currentScreen);

  return (
    <div className="iphone-container selection:bg-rail-yellow/30 bg-[#FBFBFB]">
      {/* Dynamic Screen Content */}
      <div className="h-full pb-20">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentScreen}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3, ease: 'easeOut' }}
            className="h-full"
          >
            {renderScreen()}
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Bottom Navigation */}
      {showNavbar && (
        <nav className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-white border-t border-gray-100 flex justify-between items-center px-6 py-4 safe-bottom z-50">
          <NavButton 
            active={currentScreen === 'home'} 
            onClick={() => navigateTo('home')} 
            icon={<Home size={24} />} 
            label="Home" 
          />
          <NavButton 
            active={currentScreen === 'trainDashboard' || currentScreen === 'tracking'} 
            onClick={() => navigateTo('trainDashboard')} 
            icon={<Map size={24} />} 
            label="Track" 
          />
          <NavButton 
            active={currentScreen === 'services'} 
            onClick={() => navigateTo('services')} 
            icon={<Clock size={24} />} 
            label="Services" 
          />
          <NavButton 
            active={currentScreen === 'food'} 
            onClick={() => navigateTo('food')} 
            icon={<Utensils size={24} />} 
            label="Food" 
          />
          <NavButton 
            active={currentScreen === 'profile'} 
            onClick={() => navigateTo('profile')} 
            icon={<User size={24} />} 
            label="Profile" 
          />
        </nav>
      )}
    </div>
  );
}

function NavButton({ active, onClick, icon, label }: { active: boolean, onClick: () => void, icon: ReactNode, label: string }) {
  return (
    <button 
      onClick={onClick}
      className={`flex flex-col items-center gap-1 transition-colors ${active ? 'text-rail-yellow' : 'text-gray-400'}`}
    >
      <div className={`${active ? 'scale-110' : ''} transition-transform`}>
        {icon}
      </div>
      <span className="text-[10px] font-medium">{label}</span>
    </button>
  );
}
