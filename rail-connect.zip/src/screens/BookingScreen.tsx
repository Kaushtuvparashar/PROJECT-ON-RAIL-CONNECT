import { useState } from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, Search, MapPin, Calendar, Users, ChevronRight, History } from 'lucide-react';
import { Screen } from '../App';

export default function BookingScreen({ navigate, goBack }: { navigate: (s: Screen) => void, goBack: () => void }) {
  const [from, setFrom] = useState('New Delhi');
  const [to, setTo] = useState('Mumbai Central');

  return (
    <div className="h-full flex flex-col bg-white">
      {/* Header */}
      <div className="p-6 bg-white shrink-0">
        <button onClick={goBack} className="p-2 -ml-2 mb-4">
          <ArrowLeft size={24} />
        </button>
        <h1 className="text-4xl font-bold text-rail-dark tracking-tighter">Book Journey</h1>
        <p className="text-gray-400 font-medium text-lg leading-tight mt-1">Travel across India in style</p>
      </div>

      <div className="flex-1 overflow-y-auto px-6 py-8 space-y-10">
        {/* Route Selector */}
        <div className="relative space-y-4">
          <div className="bg-gray-50 p-8 rounded-[40px] flex items-center gap-6 relative border border-gray-100">
             <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center shadow-sm shrink-0">
                <MapPin className="text-rail-yellow" size={28} />
             </div>
             <div className="flex-1">
                <span className="text-gray-400 font-bold uppercase text-[10px] tracking-widest mb-1 block">From</span>
                <input 
                  type="text" 
                  value={from}
                  onChange={(e) => setFrom(e.target.value)}
                  className="bg-transparent text-2xl font-black text-rail-dark w-full outline-none"
                />
             </div>
          </div>

          {/* Swap Button */}
          <button 
            onClick={() => {
               const temp = from;
               setFrom(to);
               setTo(temp);
            }}
            className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-10 w-16 h-16 bg-rail-yellow rounded-2xl shadow-xl shadow-rail-yellow/30 flex items-center justify-center border-4 border-white active:rotate-180 transition-transform duration-500"
          >
             <History size={24} className="text-rail-dark" />
          </button>

          <div className="bg-gray-50 p-8 rounded-[40px] flex items-center gap-6 border border-gray-100">
             <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center shadow-sm shrink-0">
                <MapPin className="text-blue-500" size={28} />
             </div>
             <div className="flex-1">
                <span className="text-gray-400 font-bold uppercase text-[10px] tracking-widest mb-1 block">To</span>
                <input 
                  type="text" 
                  value={to}
                  onChange={(e) => setTo(e.target.value)}
                  className="bg-transparent text-2xl font-black text-rail-dark w-full outline-none"
                />
             </div>
          </div>
        </div>

        {/* Date & Guests */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-gray-50 p-6 rounded-[32px] border border-gray-100">
             <span className="text-gray-400 font-bold uppercase text-[10px] tracking-widest mb-3 block">Date</span>
             <div className="flex items-center gap-3">
                <Calendar className="text-gray-300" size={20} />
                <span className="text-lg font-black text-rail-dark">21 May 2025</span>
             </div>
          </div>
          <div className="bg-gray-50 p-6 rounded-[32px] border border-gray-100">
             <span className="text-gray-400 font-bold uppercase text-[10px] tracking-widest mb-3 block">Passengers</span>
             <div className="flex items-center gap-3">
                <Users className="text-gray-300" size={20} />
                <span className="text-lg font-black text-rail-dark">01</span>
             </div>
          </div>
        </div>

        {/* Class Selection */}
        <div className="space-y-4">
           <span className="text-gray-400 font-bold uppercase text-xs tracking-widest">Travel Class</span>
           <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-none">
              {['Sleeper', '3rd AC', '2nd AC', '1st AC'].map((cls, i) => (
                <button 
                  key={cls}
                  className={`px-8 py-5 rounded-[24px] font-black whitespace-nowrap border transition-all text-lg ${i === 1 ? 'bg-rail-yellow text-rail-dark border-rail-yellow shadow-lg shadow-rail-yellow/20' : 'bg-white text-gray-400 border-gray-100'}`}
                >
                  {cls}
                </button>
              ))}
           </div>
        </div>
      </div>

      <div className="p-6 pb-12 shrink-0">
        <motion.button 
          whileTap={{ scale: 0.98 }}
          onClick={() => navigate('seats')}
          className="w-full bg-rail-dark text-white py-6 rounded-[32px] flex items-center justify-center gap-4 text-2xl font-black shadow-2xl shadow-rail-dark/20"
        >
          <Search size={28} />
          Search Trains
        </motion.button>
      </div>
    </div>
  );
}
