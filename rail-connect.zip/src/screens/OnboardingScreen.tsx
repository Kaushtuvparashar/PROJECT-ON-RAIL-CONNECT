import { motion } from 'motion/react';

export default function OnboardingScreen({ onNext }: { onNext: () => void }) {
  return (
    <div className="h-full flex flex-col bg-white overflow-hidden">
      <div className="relative flex-1">
        <motion.img
          initial={{ scale: 1.2, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 1.5 }}
          src="https://images.unsplash.com/photo-1474487056235-5264ecc04a71?q=80&w=800"
          className="w-full h-full object-cover"
          alt="Train view"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-white via-white/20 to-transparent" />
      </div>
      
      <div className="p-8 pb-12 flex flex-col items-center text-center gap-8 relative -mt-40 z-10">
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="bg-white rounded-[40px] p-10 shadow-2xl shadow-rail-yellow/10 border border-gray-50 flex flex-col gap-4 max-w-sm"
        >
          <div className="w-24 h-24 mx-auto bg-rail-yellow/10 rounded-full flex items-center justify-center p-2">
            <img 
              src="https://img.icons8.com/color/144/child-skin-type-1.png" 
              alt="Railo" 
              className="w-16 h-16"
              referrerPolicy="no-referrer"
            />
          </div>
          <div>
            <h2 className="text-3xl font-bold text-rail-dark">
              Hi! I'm <span className="text-rail-yellow">Railo</span>
            </h2>
            <p className="text-lg font-semibold text-gray-500">Your AI travel buddy</p>
          </div>
          <p className="text-gray-400 text-lg">
            Let's make your journey<br />
            <span className="font-bold text-rail-dark">Safe, Easy & Smart!</span>
          </p>
        </motion.div>
        
        <div className="w-full space-y-6">
          <button
            onClick={onNext}
            className="w-full bg-rail-yellow text-rail-dark py-5 rounded-3xl text-xl font-bold shadow-xl shadow-rail-yellow/30 active:scale-95 transition-transform"
          >
            Get Started
          </button>
          
          <div className="flex justify-center gap-2">
            <div className="w-8 h-2 rounded-full bg-rail-yellow" />
            <div className="w-2 h-2 rounded-full bg-gray-200" />
            <div className="w-2 h-2 rounded-full bg-gray-200" />
          </div>
        </div>
      </div>
    </div>
  );
}
