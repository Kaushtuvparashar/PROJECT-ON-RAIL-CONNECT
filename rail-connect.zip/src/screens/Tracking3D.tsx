import { motion } from 'motion/react';
import { ArrowLeft, Compass, Info, Map as MapIcon, Layers } from 'lucide-react';
import { MOCK_TRAINS } from '../constants';

export default function Tracking3D({ goBack }: { goBack: () => void }) {
  const train = MOCK_TRAINS[0];

  return (
    <div className="h-full flex flex-col bg-rail-dark overflow-hidden relative">
      {/* 3D Scene Mockup using pure CSS/Tailwind */}
      <div className="absolute inset-0 perspective-[1000px]">
        <div className="absolute inset-0 bg-[#0A0A0A] flex items-center justify-center">
            {/* Grid floor */}
            <div className="absolute w-[200%] h-[200%] bg-[linear-gradient(#222_1px,transparent_1px),linear-gradient(90deg,#222_1px,transparent_1px)] bg-[size:40px_40px] transform rotateX(60deg) translateZ(-400px) opacity-30 shadow-[inset_0_0_200px_rgba(0,0,0,1)]" />
            
            {/* Train Tracks */}
            <div className="absolute w-20 h-[3000px] bg-[#111] transform rotateX(60deg) translateZ(-390px) flex flex-col items-center gap-1 shadow-inner">
               {Array.from({ length: 100 }).map((_, i) => (
                 <div key={i} className="w-24 h-2 bg-[#222] shadow-sm" />
               ))}
            </div>

            {/* Simulated 3D Train */}
            <motion.div 
               animate={{ y: [-100, 100] }}
               transition={{ duration: 10, repeat: Infinity, ease: 'linear' }}
               className="relative z-10 transform-gpu rotateX(60deg) rotateZ(-15deg)"
            >
               <div className="w-16 h-80 bg-rail-yellow rounded-t-3xl relative shadow-[10px_20px_50px_rgba(0,0,0,0.5)] border-b-[20px] border-rail-dark/20">
                  <div className="absolute inset-x-2 top-4 bottom-4 flex flex-col gap-4">
                     {Array.from({ length: 6 }).map((_, i) => (
                       <div key={i} className="flex-1 bg-rail-dark/30 rounded-md" />
                     ))}
                  </div>
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 w-8 h-4 bg-rail-dark rounded-full" />
                  {/* Glow */}
                  <div className="absolute -top-10 left-1/2 -translate-x-1/2 w-20 h-20 bg-rail-yellow/40 blur-2xl rounded-full" />
               </div>
            </motion.div>
        </div>
      </div>

      {/* HUD Elements */}
      <div className="absolute inset-0 p-6 flex flex-col pointer-events-none">
        {/* Header HUD */}
        <div className="flex items-center justify-between pointer-events-auto">
          <button onClick={goBack} className="p-4 bg-white/10 backdrop-blur-md border border-white/10 rounded-[20px] text-white active:scale-95">
            <ArrowLeft size={24} />
          </button>
          <div className="flex-1 flex flex-col items-center">
             <div className="bg-white/10 backdrop-blur-md px-6 py-2 rounded-full border border-white/10 flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-rail-yellow animate-pulse" />
                <span className="text-white font-black text-xs uppercase tracking-widest tracking-tighter">Live 3D View</span>
             </div>
          </div>
          <button className="p-4 bg-rail-yellow border border-rail-yellow/20 rounded-[20px] text-rail-dark font-black shadow-lg shadow-rail-yellow/20">
             HUD
          </button>
        </div>

        <div className="mt-auto space-y-6 pointer-events-auto">
          {/* Compass / Orientation */}
          <div className="flex justify-between items-end">
            <div className="bg-white/10 backdrop-blur-3xl p-6 rounded-[40px] border border-white/10 text-white flex gap-8 items-center">
               <div className="relative w-20 h-20 flex items-center justify-center">
                  <div className="absolute inset-0 border-4 border-white/10 rounded-full" />
                  <Compass className="text-rail-yellow" size={40} />
                  <span className="absolute -top-2 left-1/2 -translate-x-1/2 font-black text-xs">N</span>
               </div>
               <div className="flex flex-col">
                  <span className="text-4xl font-black text-rail-yellow tracking-tighter italic">82</span>
                  <span className="text-[10px] font-bold opacity-50 uppercase tracking-widest">KM/H</span>
               </div>
               <div className="w-[1px] h-12 bg-white/10 shrink-0" />
               <div className="flex flex-col">
                  <span className="text-2xl font-black text-white tracking-tighter">17° <span className="text-lg opacity-40 font-medium">NE</span></span>
                  <span className="text-[10px] font-bold opacity-50 uppercase tracking-widest">Azimuth</span>
               </div>
            </div>

            <div className="flex flex-col gap-3">
               <button className="w-14 h-14 bg-white/10 backdrop-blur-md rounded-2xl flex items-center justify-center text-white border border-white/10"><Layers size={20}/></button>
               <button className="w-14 h-14 bg-white/10 backdrop-blur-md rounded-2xl flex items-center justify-center text-white border border-white/10"><MapIcon size={20}/></button>
               <button className="w-14 h-14 bg-rail-yellow rounded-2xl flex items-center justify-center text-rail-dark shadow-xl shadow-rail-yellow/20 font-black"><Info size={20}/></button>
            </div>
          </div>

          {/* Current Location HUD */}
          <div className="bg-white/10 backdrop-blur-3xl p-8 rounded-[40px] border border-white/10 text-white">
            <div className="flex items-center justify-between mb-6">
               <div className="flex flex-col">
                  <span className="text-[10px] font-bold text-rail-yellow uppercase tracking-widest mb-1">Current Sector</span>
                  <span className="text-3xl font-black">{train.nextStation} Range</span>
               </div>
               <div className="text-right">
                  <span className="text-[10px] font-bold opacity-50 uppercase tracking-widest mb-1">Signal</span>
                  <div className="flex gap-0.5">
                     <div className="w-1.5 h-3 bg-rail-yellow rounded-full" />
                     <div className="w-1.5 h-4 bg-rail-yellow rounded-full" />
                     <div className="w-1.5 h-5 bg-rail-yellow rounded-full" />
                     <div className="w-1.5 h-6 bg-rail-yellow/30 rounded-full" />
                  </div>
               </div>
            </div>
            
            <div className="space-y-4">
              <div className="flex justify-between items-center px-1">
                 <span className="text-xs font-bold opacity-50">NDLS</span>
                 <span className="text-xs font-bold text-rail-yellow">823 KM REMAINING</span>
                 <span className="text-xs font-bold opacity-50">BCT</span>
              </div>
              <div className="relative h-2 bg-white/5 rounded-full overflow-hidden">
                <div className="absolute left-0 top-0 h-full w-[45%] bg-rail-yellow rounded-full" />
              </div>
            </div>
          </div>
        </div>
        <div className="h-10 shrink-0" />
      </div>
    </div>
  );
}
