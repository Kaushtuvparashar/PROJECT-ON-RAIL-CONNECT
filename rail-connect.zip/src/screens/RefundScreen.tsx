import { useState } from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, AlertCircle, CheckCircle2, ChevronRight, Calculator } from 'lucide-react';

export default function RefundScreen({ goBack }: { goBack: () => void }) {
  const [step, setStep] = useState<'form' | 'success'>('form');

  return (
    <div className="h-full flex flex-col bg-[#FBFBFB]">
      {/* Header */}
      <div className="p-6 flex items-center justify-between shrink-0 bg-white">
        <button onClick={goBack} className="p-2 -ml-2">
          <ArrowLeft size={24} />
        </button>
        <h1 className="text-2xl font-bold flex-1 text-center">Refund Request</h1>
        <div className="w-10" />
      </div>

      <div className="flex-1 overflow-y-auto px-6 py-8">
        {step === 'form' ? (
          <div className="space-y-8 pb-10">
            {/* Warning */}
            <div className="bg-orange-50 p-6 rounded-[32px] flex gap-5 border border-orange-100">
               <AlertCircle className="text-orange-500 shrink-0" size={28} />
               <p className="text-orange-900/60 font-bold leading-tight">
                 Cancellation fee of <span className="text-orange-600 font-black">₹240</span> will be deducted as per IRCTC policy.
               </p>
            </div>

            {/* Ticket Info Summary */}
            <div className="bg-white p-8 rounded-[40px] border border-gray-100 shadow-sm space-y-6">
               <div className="flex justify-between items-center">
                  <div className="flex flex-col">
                     <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Journey</span>
                     <span className="text-2xl font-black text-rail-dark tracking-tighter">NDLS → BCT</span>
                  </div>
                  <div className="bg-gray-50 px-4 py-2 rounded-2xl font-black text-gray-400">
                    B2-45
                  </div>
               </div>
               <div className="h-[1px] bg-gray-50" />
               <div className="grid grid-cols-2 gap-4">
                  <div className="flex flex-col gap-1">
                     <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Total Paid</span>
                     <span className="text-xl font-black text-rail-dark tracking-tighter">₹1,230</span>
                  </div>
                  <div className="flex flex-col gap-1 items-end">
                     <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Refund Amount</span>
                     <span className="text-xl font-black text-green-500 tracking-tighter">₹990</span>
                  </div>
               </div>
            </div>

            {/* Reason Selector */}
            <div className="space-y-4">
               <span className="text-gray-400 font-bold uppercase text-xs tracking-widest">Reason for Cancellation</span>
               <div className="space-y-3">
                  {[
                    'Plan changed',
                    'Accidental booking',
                    'Train delayed',
                    'Other'
                  ].map((reason, i) => (
                    <button 
                      key={reason}
                      className={`w-full p-6 bg-white border border-gray-100 rounded-[28px] text-left font-bold transition-all flex items-center justify-between ${i === 0 ? 'border-rail-yellow shadow-lg shadow-rail-yellow/5' : ''}`}
                    >
                      {reason}
                      {i === 0 && <div className="w-6 h-6 bg-rail-yellow rounded-full flex items-center justify-center"><CheckCircle2 size={16}/></div>}
                    </button>
                  ))}
               </div>
            </div>

            <motion.button 
              whileTap={{ scale: 0.98 }}
              onClick={() => setStep('success')}
              className="w-full bg-rail-yellow py-6 rounded-[32px] text-2xl font-black shadow-xl shadow-rail-yellow/30"
            >
              Request Refund
            </motion.button>
          </div>
        ) : (
          <div className="h-full flex flex-col items-center justify-center text-center px-4 space-y-8 pb-20">
             <div className="w-40 h-40 bg-green-50 rounded-[48px] flex items-center justify-center shadow-inner">
                <CheckCircle2 className="text-green-500" size={80} />
             </div>
             <div className="space-y-2">
                <h2 className="text-4xl font-black text-rail-dark tracking-tighter">Request Success!</h2>
                <p className="text-gray-400 font-medium text-lg leading-tight">Your refund of <span className="text-green-500 font-bold">₹990</span> will be<br />credited within 3-5 business days.</p>
             </div>
             <div className="bg-gray-50 p-6 rounded-[32px] w-full border border-gray-100">
                <div className="flex flex-col gap-1 items-center">
                   <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Reference ID</span>
                   <span className="text-xl font-black text-rail-dark">REF-9283741</span>
                </div>
             </div>
             <button 
               onClick={goBack}
               className="text-rail-yellow font-black text-xl flex items-center gap-2"
             >
               Back to Home <ChevronRight size={20} />
             </button>
          </div>
        )}
      </div>
    </div>
  );
}
