import { useState } from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, Search, Star, ShoppingBag, Leaf, Flame, Coffee, X } from 'lucide-react';
import { FOOD_MENU } from '../constants';
import { Screen } from '../App';

export default function FoodOrder({ navigate, goBack }: { navigate: (s: Screen) => void, goBack: () => void }) {
  const [activeCategory, setActiveCategory] = useState<'veg' | 'non-veg' | 'snacks' | 'drinks'>('veg');
  const [cart, setCart] = useState<{ id: string, count: number }[]>([]);

  const addToCart = (id: string) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === id);
      if (existing) return prev.map(item => item.id === id ? { ...item, count: item.count + 1 } : item);
      return [...prev, { id, count: 1 }];
    });
  };

  const cartTotal = cart.reduce((total, cartItem) => {
    const food = FOOD_MENU.find(f => f.id === cartItem.id);
    return total + (food?.price || 0) * cartItem.count;
  }, 0);

  const cartCount = cart.reduce((sum, item) => sum + item.count, 0);

  return (
    <div className="h-full flex flex-col bg-[#FBFBFB]">
      {/* Header */}
      <div className="p-6 bg-white shrink-0">
        <button onClick={goBack} className="p-2 -ml-2 mb-4">
          <ArrowLeft size={24} />
        </button>
        <h1 className="text-4xl font-bold text-rail-dark">Food Order</h1>
        <p className="text-gray-400 font-medium text-lg tracking-tight">Delicious food on your seat</p>
      </div>

      <div className="flex-1 overflow-y-auto px-6 py-6 space-y-8">
        {/* Banner Card */}
        <div className="bg-rail-yellow rounded-[40px] p-10 relative overflow-hidden shadow-xl shadow-rail-yellow/20">
          <div className="relative z-10 max-w-[60%]">
            <h2 className="text-5xl font-black text-rail-dark tracking-tighter leading-none mb-2">RAIL BITES</h2>
            <p className="text-rail-dark/60 font-bold text-lg leading-tight">Tasty Food, On Track Bento</p>
          </div>
          <img 
            src="https://images.unsplash.com/photo-1546069901-ba9599a7e63c?q=80&w=400" 
            className="absolute -right-10 -bottom-10 w-64 h-64 object-cover rounded-full border-8 border-white shadow-2xl origin-bottom-right rotate-12"
            alt="Food"
            referrerPolicy="no-referrer"
          />
        </div>

        {/* Categories */}
        <div className="flex gap-4 overflow-x-auto pb-2 scrollbar-none">
          {[
            { id: 'veg', label: 'Veg', icon: <Leaf size={18} /> },
            { id: 'non-veg', label: 'Non-Veg', icon: <Flame size={18} /> },
            { id: 'snacks', label: 'Snacks', icon: <Utensils size={18} /> },
            { id: 'drinks', label: 'Drinks', icon: <Coffee size={18} /> }
          ].map(cat => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id as any)}
              className={`flex items-center gap-2 px-6 py-3.5 rounded-full font-bold transition-all border ${
                activeCategory === cat.id 
                  ? 'bg-rail-yellow text-rail-dark border-rail-yellow shadow-md' 
                  : 'bg-white text-gray-400 border-gray-100'
              }`}
            >
              {cat.icon}
              {cat.label}
            </button>
          ))}
        </div>

        {/* Food List */}
        <div className="space-y-4">
          {FOOD_MENU.map((item) => (
            <motion.div 
              key={item.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="bg-white p-5 rounded-[32px] border border-gray-50 flex gap-6 items-center shadow-sm"
            >
              <div className="w-28 h-28 rounded-3xl overflow-hidden shrink-0 shadow-inner">
                <img src={item.image} className="w-full h-full object-cover" alt={item.name} referrerPolicy="no-referrer" />
              </div>
              <div className="flex-1 space-y-1">
                <h3 className="text-xl font-bold text-rail-dark leading-tight">{item.name}</h3>
                <div className="flex items-center gap-3">
                  <span className="text-2xl font-black text-rail-dark tracking-tighter">₹{item.price}</span>
                  <div className="flex items-center gap-1.5 bg-yellow-50 px-2 py-0.5 rounded-lg">
                    <Star size={12} className="text-yellow-500 fill-yellow-500" />
                    <span className="text-xs font-black text-yellow-500">{item.rating}</span>
                  </div>
                </div>
              </div>
              <button 
                onClick={() => addToCart(item.id)}
                className="bg-rail-yellow px-6 py-3 rounded-2xl font-black shadow-lg shadow-rail-yellow/20 active:scale-95 transition-transform"
              >
                Add +
              </button>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Cart Summary FAB */}
      {cartCount > 0 && (
        <div className="p-6 safe-bottom shrink-0 bg-white border-t border-gray-100">
          <motion.button 
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            className="w-full bg-rail-yellow rounded-[24px] p-5 flex items-center justify-between shadow-xl shadow-rail-yellow/30"
          >
            <div className="flex items-center gap-4">
              <div className="bg-rail-dark/10 p-2 rounded-xl">
                <span className="font-black text-lg">View Cart ({cartCount})</span>
              </div>
            </div>
            <div className="flex items-center gap-3 bg-rail-dark text-white px-4 py-2 rounded-2xl">
              <ShoppingBag size={20} />
              <span className="text-xl font-black tracking-tighter">₹{cartTotal}</span>
            </div>
          </motion.button>
        </div>
      )}
    </div>
  );
}

function Utensils({ size, className }: { size: number, className?: string }) {
  return <ShoppingBag size={size} className={className} />;
}
