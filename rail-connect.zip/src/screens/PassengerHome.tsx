import { Search, Bell, ChevronRight, MapPin } from 'lucide-react';
import { motion } from 'motion/react';
import { MOCK_TRAINS } from '../constants';
import { Screen } from '../App';

export default function PassengerHome({ navigate }: { navigate: (s: Screen) => void }) {
  return (
    <div className="h-full overflow-y-auto pb-6">
      {/* Header */}
      <div className="p-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div 
            className="w-14 h-14 rounded-full border-4 border-white shadow-md overflow-hidden cursor-pointer"
            onClick={() => navigate('profile')}
          >
            <img 
              src="https://img.icons8.com/color/144/child-skin-type-1.png" 
              alt="Profile" 
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          <div>
            <h3 className="text-2xl font-bold flex items-center gap-1">
              Hi, Rahul <span className="text-2xl">👋</span>
            </h3>
            <p className="text-gray-400 font-medium tracking-tight">Where do you want to go today?</p>
          </div>
        </div>
        <button 
          onClick={() => navigate('notifications')}
          className="w-12 h-12 bg-white rounded-2xl shadow-sm border border-gray-50 flex items-center justify-center relative"
        >
          <Bell size={24} className="text-gray-600" />
          <div className="absolute top-3 right-3 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-white" />
        </button>
      </div>

      {/* Search Bar */}
      <div className="px-6 mb-8">
        <button 
          onClick={() => navigate('booking')}
          className="w-full bg-white border border-gray-100 rounded-2xl p-4 flex items-center gap-3 shadow-sm"
        >
          <Search className="text-gray-400" size={20} />
          <span className="text-gray-400 font-medium">Search trains, stations...</span>
        </button>
      </div>

      {/* Popular Trains */}
      <div className="px-6 mb-6 flex items-center justify-between">
        <h2 className="text-2xl font-bold text-rail-dark">Popular Trains</h2>
        <button className="text-rail-yellow font-bold">View All</button>
      </div>

      <div className="px-6 space-y-6">
        {/* Main Card */}
        <motion.div 
          whileTap={{ scale: 0.98 }}
          onClick={() => navigate('trainDashboard')}
          className="bg-rail-yellow rounded-[32px] p-8 text-rail-dark relative overflow-hidden shadow-xl shadow-rail-yellow/20"
        >
          <div className="flex flex-col gap-1 mb-4 relative z-10">
            <span className="text-2xl font-black">12951</span>
            <h3 className="text-3xl font-black leading-none">Rajdhani Express</h3>
          </div>
          
          <div className="flex items-center gap-4 mb-6 relative z-10">
            <div className="flex flex-col">
              <span className="text-2xl font-black">NDLS</span>
              <span className="text-sm font-bold opacity-70">New Delhi</span>
            </div>
            <ChevronRight className="opacity-50" size={24} />
            <div className="flex flex-col">
              <span className="text-2xl font-black">BCT</span>
              <span className="text-sm font-bold opacity-70">Mumbai Central</span>
            </div>
          </div>

          <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-md px-4 py-2 rounded-full relative z-10">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
            <span className="text-sm font-black uppercase tracking-tight">Running On Time</span>
          </div>

          <img 
            src="https://img.icons8.com/color/144/train.png" 
            className="absolute -right-10 -bottom-4 w-52 h-52 opacity-90 drop-shadow-2xl"
            alt="Train"
            referrerPolicy="no-referrer"
          />
        </motion.div>

        {/* List of other trains */}
        <div className="grid grid-cols-2 gap-4">
          {MOCK_TRAINS.slice(1).map((train) => (
            <motion.div 
              key={train.id}
              whileTap={{ scale: 0.95 }}
              className="bg-white p-6 rounded-[28px] border border-gray-100 shadow-sm flex flex-col gap-3"
            >
              <span className="font-black text-xl text-rail-dark leading-none">{train.number}</span>
              <h4 className="font-bold text-gray-500 text-sm leading-tight">{train.name}</h4>
              
              <div className="flex items-center gap-2 text-rail-dark font-black">
                <span>{train.fromCode}</span>
                <ChevronRight size={14} className="opacity-30" />
                <span>{train.toCode}</span>
              </div>

              <div className={`text-[10px] font-black uppercase tracking-widest flex items-center gap-1 ${train.status === 'on-time' ? 'text-green-500' : 'text-red-500'}`}>
                {train.status === 'on-time' ? '🟢 Running On Time' : `🔴 Delayed ${train.delay}`}
              </div>
              
              <div className="mt-2 h-24 overflow-hidden rounded-xl bg-gray-50 flex items-center justify-center p-4">
                <img 
                  src={train.id === '2' ? "https://img.icons8.com/color/144/bullet-train.png" : "https://img.icons8.com/color/144/train.png"} 
                  className="w-full h-full object-contain"
                  alt="Train side"
                  referrerPolicy="no-referrer"
                />
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
