import { ArrowLeft, Bell, BellRing, Settings, Circle } from 'lucide-react';
import { motion } from 'motion/react';
import { NOTIFICATIONS } from '../constants';

export default function NotificationsScreen({ goBack }: { goBack: () => void }) {
  return (
    <div className="h-full flex flex-col bg-white">
      {/* Header */}
      <div className="p-6 flex items-center justify-between bg-white shrink-0">
        <button onClick={goBack} className="p-2 -ml-2">
          <ArrowLeft size={24} />
        </button>
        <h1 className="text-3xl font-bold flex-1 text-center">Notifications</h1>
        <button className="p-2 -mr-2 text-gray-400">
          <Settings size={24} />
        </button>
      </div>

      {/* Filter Tabs */}
      <div className="px-6 py-4 flex gap-3 overflow-x-auto scrollbar-none shrink-0 border-b border-gray-50">
        {['All', 'Alerts', 'Offers', 'Updates'].map((tab, i) => (
          <button 
            key={tab}
            className={`px-8 py-3.5 rounded-2xl font-bold text-lg transition-all ${i === 0 ? 'bg-rail-yellow text-rail-dark shadow-lg shadow-rail-yellow/30 border border-rail-yellow' : 'bg-white text-gray-400 border border-gray-100'}`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Notifications List */}
      <div className="flex-1 overflow-y-auto px-6 py-8 space-y-8">
        {NOTIFICATIONS.map((notif, i) => (
          <motion.div 
            key={notif.id}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: i * 0.05 }}
            className="flex items-start gap-6 group cursor-pointer"
          >
            <div className={`w-16 h-16 rounded-[22px] flex items-center justify-center shrink-0 shadow-sm ${
              notif.type === 'alert' ? 'bg-orange-50' : notif.id === 'n3' ? 'bg-green-50' : 'bg-blue-50'
            }`}>
              <Bell className={
                notif.type === 'alert' ? 'text-orange-500' : notif.id === 'n3' ? 'text-green-500' : 'text-blue-500'
              } size={28} />
            </div>
            <div className="flex-1 border-b border-gray-50 pb-8 pr-2">
              <div className="flex justify-between items-start mb-2">
                <h3 className="font-black text-xl text-rail-dark leading-none">{notif.title}</h3>
                <span className="text-[11px] font-bold text-gray-400 uppercase tracking-widest">{notif.time}</span>
              </div>
              <p className="text-gray-500 font-medium text-lg leading-snug">{notif.message}</p>
            </div>
          </motion.div>
        ))}
        
        {/* Placeholder for more notifications */}
        <div className="flex items-start gap-6 group">
          <div className="w-16 h-16 rounded-[22px] bg-purple-50 flex items-center justify-center shrink-0">
             <BellRing className="text-purple-500" size={28} />
          </div>
          <div className="flex-1 border-b border-gray-50 pb-8 pr-2">
            <div className="flex justify-between items-start mb-2">
              <h3 className="font-black text-xl text-rail-dark leading-none">Platform Change</h3>
              <span className="text-[11px] font-bold text-gray-400 uppercase tracking-widest">09:20 AM</span>
            </div>
            <p className="text-gray-500 font-medium text-lg leading-snug">Agra Cantt platform changed to 2</p>
          </div>
        </div>
      </div>
    </div>
  );
}
