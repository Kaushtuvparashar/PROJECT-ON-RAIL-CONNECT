import { useState } from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, BellRing, Clock, MapPin, ChevronRight, Power } from 'lucide-react';
import { MOCK_TRAINS } from '../constants';

export default function StationAlarm({ goBack }: { goBack: () => void }) {
  const [distance, setDistance] = useState(10); // KM
  const [isActive, setIsActive] = useState(false);
  const train = MOCK_TRAINS[0];

  return (
    <div className="h-full flex flex-col bg-white">
      {/* Header */}
      <div className="p-6 flex items-center justify-between shrink-0">
        <button onClick={goBack} className="p-2 -ml-2">
          <ArrowLeft size={24} />
        </button>
        <h1 className="text-2xl font-bold flex-1 text-center">Station Alarm</h1>
        <div className="w-10" />
      </div>

      <div className="flex-1 overflow-y-auto px-6 py-8 space-y-12">
        {/* Info Card */}
        <div className="text-center space-y-2">
          <div className="w-32 h-32 bg-rail-yellow/10 rounded-full flex items-center justify-center mx-auto mb-6">
            <img src="https://img.icons8.com/color/144/alarm-clock.png" className="w-20 h-20" alt="Alarm" referrerPolicy="no-referrer" />
          </div>
          <h2 className="text-4xl font-black text-rail-dark tracking-tighter">Wake me up!</h2>
          <p className="text-gray-400 font-medium text-lg leading-tight">We will alert you before<br />your destination station.</p>
        </div>

        {/* Train Selector */}
        <div className="bg-gray-50 p-6 rounded-[32px] flex items-center justify-between border border-gray-100">
          <div className="flex flex-col">
            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Destination</span>
            <span className="text-2xl font-black text-rail-dark">{train.to} ({train.toCode})</span>
          </div>
          <ChevronRight className="text-gray-300" size={24} />
        </div>

        {/* Distance Selector */}
        <div className="space-y-6">
          <div className="flex justify-between items-end">
            <span className="text-gray-400 font-bold uppercase text-xs tracking-widest">Alert distance</span>
            <span className="text-5xl font-black text-rail-dark tracking-tighter">{distance} <span className="text-2xl text-gray-300">KM</span></span>
          </div>
          <div className="relative pt-10 pb-6">
            <input 
              type="range" 
              min="5" 
              max="100" 
              step="5"
              value={distance}
              onChange={(e) => setDistance(parseInt(e.target.value))}
              className="w-full accent-rail-yellow h-3 rounded-full bg-gray-100 appearance-none cursor-pointer"
            />
            <div className="flex justify-between mt-4 text-xs font-bold text-gray-300 uppercase tracking-widest">
               <span>5 KM</span>
               <span>50 KM</span>
               <span>100 KM</span>
            </div>
          </div>
        </div>

        {/* Sound Selection */}
        <div className="space-y-4">
           <span className="text-gray-400 font-bold uppercase text-xs tracking-widest">Alarm Sound</span>
           <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-none">
              {['Classic', 'Bird Chirp', 'Soft Piano', 'Train Horn'].map((sound, i) => (
                <button 
                  key={sound}
                  className={`px-8 py-4 rounded-2xl font-bold whitespace-nowrap border transition-all ${i === 0 ? 'bg-rail-yellow text-rail-dark border-rail-yellow shadow-md' : 'bg-white text-gray-400 border-gray-100'}`}
                >
                  {sound}
                </button>
              ))}
           </div>
        </div>
      </div>

      {/* Action FAB */}
      <div className="p-6 pb-12 shrink-0">
        <motion.button 
          whileTap={{ scale: 0.98 }}
          onClick={() => setIsActive(!isActive)}
          className={`w-full py-6 rounded-[32px] flex items-center justify-center gap-4 text-2xl font-black shadow-xl transition-all ${
            isActive 
              ? 'bg-red-500 text-white shadow-red-500/30' 
              : 'bg-rail-yellow text-rail-dark shadow-rail-yellow/30'
          }`}
        >
          <Power size={28} />
          {isActive ? 'Deactivate Alarm' : 'Set Alarm'}
        </motion.button>
      </div>
    </div>
  );
}
