import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowLeft, ChevronRight, Check } from 'lucide-react';
import { Screen } from '../App';

export default function SeatSelection({ navigate, goBack }: { navigate: (s: Screen) => void, goBack: () => void }) {
  const [selectedSeat, setSelectedSeat] = useState<string | null>(null);
  const [hoveredCoach, setHoveredCoach] = useState<string | null>(null);

  const coaches = [
    { id: 'B1', available: 12 },
    { id: 'B2', available: 8 },
    { id: 'B3', available: 15 },
    { id: 'B4', available: 4 },
    { id: 'B5', available: 20 },
    { id: 'B6', available: 2 },
  ];

  const seats = Array.from({ length: 48 }).map((_, i) => ({
    id: `${i + 1}`,
    type: i % 3 === 0 ? 'upper' : i % 3 === 1 ? 'middle' : 'lower',
    status: Math.random() > 0.8 ? 'booked' : 'available'
  }));

  return (
    <div className="h-full flex flex-col bg-white">
      {/* Header */}
      <div className="p-6 bg-white shrink-0">
        <button onClick={goBack} className="p-2 -ml-2 mb-4">
          <ArrowLeft size={24} />
        </button>
        <h1 className="text-4xl font-bold text-rail-dark tracking-tighter">Select Seat</h1>
        <p className="text-gray-400 font-medium text-lg leading-tight mt-1">Coach B2 - Rajdhani Express</p>
      </div>

      <div className="flex-1 overflow-y-auto px-6 py-6 pb-20">
        {/* Coach Selection & Availability Tooltip */}
        <div className="mb-10 space-y-4">
          <span className="text-gray-400 font-bold uppercase text-[10px] tracking-widest px-2">Select Coach</span>
          <div className="flex gap-3 overflow-x-auto pb-4 scrollbar-none px-2">
            {coaches.map((coach) => (
              <div
                key={coach.id}
                onMouseEnter={() => setHoveredCoach(coach.id)}
                onMouseLeave={() => setHoveredCoach(null)}
                className="relative group shrink-0"
              >
                <button
                  className={`w-16 h-16 rounded-2xl font-black text-lg transition-all flex items-center justify-center border-2 ${
                    coach.id === 'B2'
                      ? 'bg-rail-yellow border-rail-yellow text-rail-dark shadow-lg shadow-rail-yellow/20'
                      : 'bg-white border-gray-100 text-gray-400 hover:border-rail-yellow/50'
                  }`}
                >
                  {coach.id}
                </button>
                
                {/* Custom Tooltip */}
                <AnimatePresence>
                  {hoveredCoach === coach.id && (
                    <motion.div
                      initial={{ opacity: 0, y: 10, scale: 0.9 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: 10, scale: 0.9 }}
                      className="absolute bottom-full left-1/2 -translate-x-1/2 mb-3 z-50 pointer-events-none"
                    >
                      <div className="bg-rail-dark text-white text-[10px] font-black py-2 px-4 rounded-xl whitespace-nowrap shadow-xl">
                        <span className="text-rail-yellow">{coach.available}</span> SEATS LEFT
                        <div className="absolute top-full left-1/2 -translate-x-1/2 border-[6px] border-transparent border-t-rail-dark" />
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ))}
          </div>
        </div>

        {/* Legend */}
        <div className="flex justify-between mb-10 px-4">
           <div className="flex flex-col items-center gap-1">
              <div className="w-8 h-8 rounded-lg bg-gray-100" />
              <span className="text-[10px] font-black text-gray-300 uppercase tracking-widest">Available</span>
           </div>
           <div className="flex flex-col items-center gap-1">
              <div className="w-8 h-8 rounded-lg bg-rail-dark/10" />
              <span className="text-[10px] font-black text-gray-300 uppercase tracking-widest">Booked</span>
           </div>
           <div className="flex flex-col items-center gap-1">
              <div className="w-8 h-8 rounded-lg bg-rail-yellow" />
              <span className="text-[10px] font-black text-rail-dark tracking-widest">Selected</span>
           </div>
        </div>

        {/* Coach Layout */}
        <div className="bg-gray-50 rounded-[48px] p-8 space-y-12 border border-gray-100">
           {/* Section 1 */}
           <div className="grid grid-cols-4 gap-4">
              {seats.slice(0, 16).map((seat) => (
                <button
                  key={seat.id}
                  disabled={seat.status === 'booked'}
                  onClick={() => setSelectedSeat(seat.id)}
                  className={`relative w-full aspect-square rounded-2xl flex items-center justify-center font-black transition-all border ${
                    selectedSeat === seat.id 
                      ? 'bg-rail-yellow text-rail-dark border-rail-yellow shadow-lg shadow-rail-yellow/30' 
                      : seat.status === 'booked' 
                        ? 'bg-gray-200 text-gray-400 border-transparent opacity-40' 
                        : 'bg-white text-gray-400 border-gray-100'
                  }`}
                >
                  {seat.id}
                  {selectedSeat === seat.id && <Check size={12} className="absolute -top-1 -right-1 bg-rail-dark text-white rounded-full p-0.5" />}
                </button>
              ))}
           </div>
           
           <div className="flex items-center gap-4 opacity-10">
              <div className="h-0.5 bg-gray-400 flex-1" />
              <span className="text-[10px] font-black uppercase tracking-[1em]">Gangway</span>
              <div className="h-0.5 bg-gray-400 flex-1" />
           </div>

           {/* Section 2 */}
           <div className="grid grid-cols-4 gap-4">
              {seats.slice(16, 32).map((seat) => (
                <button
                  key={seat.id}
                  disabled={seat.status === 'booked'}
                  onClick={() => setSelectedSeat(seat.id)}
                  className={`w-full aspect-square rounded-2xl flex items-center justify-center font-black transition-all border ${
                    selectedSeat === seat.id 
                      ? 'bg-rail-yellow text-rail-dark border-rail-yellow shadow-lg shadow-rail-yellow/30' 
                      : seat.status === 'booked' 
                        ? 'bg-gray-200 text-gray-400 border-transparent opacity-40' 
                        : 'bg-white text-gray-400 border-gray-100'
                  }`}
                >
                  {seat.id}
                </button>
              ))}
           </div>
        </div>
      </div>

      {/* Footer Info */}
      <div className="p-6 safe-bottom shrink-0 bg-white border-t border-gray-100">
        <div className="flex justify-between items-center mb-6">
           <div className="flex flex-col">
              <span className="text-gray-400 font-bold uppercase text-[10px] tracking-widest">Selected Seat</span>
              <span className="text-3xl font-black text-rail-dark">{selectedSeat ? `B2 - ${selectedSeat}` : '--'}</span>
           </div>
           <div className="text-right">
              <span className="text-gray-400 font-bold uppercase text-[10px] tracking-widest">Total Fare</span>
              <span className="text-3xl font-black text-rail-dark tracking-tighter">₹1,230</span>
           </div>
        </div>
        <motion.button 
          whileTap={{ scale: 0.98 }}
          onClick={() => navigate('tickets')}
          disabled={!selectedSeat}
          className={`w-full py-6 rounded-[32px] text-2xl font-black shadow-xl transition-all ${
            selectedSeat 
              ? 'bg-rail-yellow text-rail-dark shadow-rail-yellow/30' 
              : 'bg-gray-100 text-gray-300'
          }`}
        >
          Confirm & Pay
        </motion.button>
      </div>
    </div>
  );
}
