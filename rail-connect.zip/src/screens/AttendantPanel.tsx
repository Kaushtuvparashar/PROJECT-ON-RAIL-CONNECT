import { useState } from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, Clock, MapPin, CheckCircle2, User, Phone, ShieldAlert, LogOut } from 'lucide-react';
import { SERVICE_REQUESTS } from '../constants';

export default function AttendantPanel({ goBack }: { goBack: () => void }) {
  const [requests, setRequests] = useState(SERVICE_REQUESTS);

  const resolveRequest = (id: string) => {
    setRequests(prev => prev.map(r => r.id === id ? { ...r, status: 'completed' } : r));
  };

  return (
    <div className="h-full flex flex-col bg-[#FBFBFB]">
      {/* Header */}
      <div className="p-8 bg-rail-dark text-white shrink-0 shadow-2xl relative overflow-hidden">
        <div className="absolute right-[-20px] top-[-20px] opacity-10">
           <ShieldAlert size={140} />
        </div>
        <div className="flex justify-between items-center mb-8 relative z-10">
           <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-white/10 rounded-2xl flex items-center justify-center backdrop-blur-md">
                 <img src="https://img.icons8.com/color/48/policeman.png" alt="Staff" />
              </div>
              <div className="flex flex-col">
                 <span className="text-[10px] font-bold opacity-50 uppercase tracking-widest">Assigned Coach</span>
                 <span className="text-3xl font-black text-rail-yellow tracking-tighter">Coach B1 / B2</span>
              </div>
           </div>
           <button onClick={goBack} className="p-4 bg-white/10 rounded-2xl active:scale-90 transition-transform">
              <LogOut size={24} />
           </button>
        </div>
        <div className="grid grid-cols-2 gap-4 relative z-10">
           <div className="bg-white/5 border border-white/5 rounded-3xl p-5 backdrop-blur-xl">
              <span className="text-[10px] font-bold opacity-50 uppercase tracking-widest block mb-1">Open Tasks</span>
              <span className="text-3xl font-black text-white">{requests.filter(r => r.status === 'pending').length}</span>
           </div>
           <div className="bg-white/5 border border-white/5 rounded-3xl p-5 backdrop-blur-xl">
              <span className="text-[10px] font-bold opacity-50 uppercase tracking-widest block mb-1">Completed</span>
              <span className="text-3xl font-black text-green-500">{requests.filter(r => r.status === 'completed').length}</span>
           </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-6 py-8 space-y-6 pb-12">
        <h2 className="text-xl font-black text-rail-dark uppercase tracking-widest opacity-40 px-2">Live Requests</h2>
        
        {requests.map((request, i) => (
          <motion.div 
            key={request.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.1 }}
            className={`bg-white p-6 rounded-[32px] border shadow-sm space-y-6 ${request.status === 'completed' ? 'border-green-100 opacity-60' : 'border-gray-50'}`}
          >
             <div className="flex justify-between items-start">
                <div className="flex items-center gap-4">
                   <div className={`p-4 rounded-2xl ${
                      request.type === 'cleaning' ? 'bg-blue-50 text-blue-500' : 'bg-red-50 text-red-500'
                   }`}>
                      <img 
                        src={request.type === 'cleaning' ? 'https://img.icons8.com/color/48/cleaning-service.png' : 'https://img.icons8.com/color/48/service.png'} 
                        className="w-8 h-8"
                        alt="Service"
                      />
                   </div>
                   <div>
                      <h3 className="font-black text-xl text-rail-dark capitalize tracking-tight">{request.type} Request</h3>
                      <span className="text-[11px] font-bold text-gray-400 tracking-widest uppercase">{request.time}</span>
                   </div>
                </div>
                <div className="bg-rail-dark text-rail-yellow px-4 py-2 rounded-2xl font-black text-lg">
                   {request.seat}
                </div>
             </div>

             <div className="flex items-center gap-3 px-1">
                <User size={18} className="text-gray-300" />
                <span className="font-bold text-gray-500">{request.passengerName}</span>
             </div>

             {request.status === 'pending' ? (
               <div className="flex gap-3">
                  <button 
                    onClick={() => resolveRequest(request.id)}
                    className="flex-1 bg-rail-yellow text-rail-dark py-4 rounded-2xl font-black text-lg shadow-lg shadow-rail-yellow/10"
                  >
                    Mark Ready
                  </button>
                  <button className="w-14 h-14 bg-gray-50 flex items-center justify-center rounded-2xl text-gray-400">
                    <Phone size={20} />
                  </button>
               </div>
             ) : (
               <div className="flex items-center justify-center gap-2 py-2 text-green-500 font-black tracking-tight">
                  <CheckCircle2 size={24} />
                  <span>Request Completed</span>
               </div>
             )}
          </motion.div>
        ))}
      </div>
    </div>
  );
}
