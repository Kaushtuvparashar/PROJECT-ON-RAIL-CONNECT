import { ArrowLeft, WashingMachine, MapPin, AlarmClock, PhoneCall, History, Settings } from 'lucide-react';
import { motion } from 'motion/react';
import { Screen } from '../App';

const SERVICES = [
  { id: 'cleaning', title: 'Cleaning', icon: 'https://img.icons8.com/color/144/cleaning-service.png', screen: 'services' },
  { id: 'food', title: 'Food Order', icon: 'https://img.icons8.com/color/144/service.png', screen: 'food' },
  { id: 'track', title: 'Track Train', icon: 'https://img.icons8.com/color/144/map-marker.png', screen: 'trainDashboard' },
  { id: 'ac', title: 'AC Control', icon: 'https://img.icons8.com/color/144/air-conditioner.png' },
  { id: 'alarm', title: 'Station Alarm', icon: 'https://img.icons8.com/color/144/alarm-clock.png', screen: 'alarm' },
  { id: 'attendant', title: 'Attendant Call', icon: 'https://img.icons8.com/color/144/client-management.png' },
  { id: 'refunds', title: 'Refunds', icon: 'https://img.icons8.com/color/144/refund.png', screen: 'refund' }
];

export default function ServicesScreen({ navigate, goBack }: { navigate: (s: Screen) => void, goBack: () => void }) {
  return (
    <div className="h-full flex flex-col bg-white">
      <div className="p-6 pb-2 bg-white">
        <button onClick={goBack} className="p-2 -ml-2 mb-4">
          <ArrowLeft size={24} />
        </button>
        <h1 className="text-4xl font-bold text-rail-dark">Our Services</h1>
        <p className="text-gray-400 font-medium text-lg mt-2 tracking-tight">Everything you need</p>
      </div>

      <div className="flex-1 overflow-y-auto px-6 py-8">
        <div className="grid grid-cols-3 gap-y-12 gap-x-4">
          {SERVICES.map((service, i) => (
            <motion.button
              key={service.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: i * 0.05 }}
              onClick={() => service.screen && navigate(service.screen as Screen)}
              className="flex flex-col items-center gap-4 active:scale-95 transition-transform"
            >
              <div className="w-20 h-20 bg-gray-50 rounded-[28px] flex items-center justify-center p-4 border border-gray-100 shadow-sm">
                <img src={service.icon} className="w-full h-full object-contain" alt={service.title} referrerPolicy="no-referrer" />
              </div>
              <span className="font-bold text-rail-dark text-center leading-tight">{service.title}</span>
            </motion.button>
          ))}
        </div>
      </div>
      
      {/* AI Assistant FAB */}
      <div className="px-6 pb-12">
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => navigate('chat')}
          className="w-full bg-rail-yellow rounded-[32px] p-6 flex items-center gap-6 shadow-xl shadow-rail-yellow/20 border border-white/20"
        >
          <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center p-2 shadow-inner">
            <img 
               src="https://img.icons8.com/color/144/child-skin-type-1.png" 
               className="w-full h-full object-contain"
               alt="Railo"
               referrerPolicy="no-referrer"
            />
          </div>
          <div className="text-left">
            <h3 className="font-black text-2xl text-rail-dark">Chat with Railo</h3>
            <p className="text-rail-dark/60 font-bold">Your AI assistant is online</p>
          </div>
        </motion.button>
      </div>
    </div>
  );
}
