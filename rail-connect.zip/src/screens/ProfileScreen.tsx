import { ReactNode } from 'react';
import { ArrowLeft, User, Bell, Shield, CreditCard, HelpCircle, LogOut, ChevronRight, Camera } from 'lucide-react';
import { motion } from 'motion/react';
import { Screen } from '../App';

export default function ProfileScreen({ navigate, goBack }: { navigate: (s: Screen) => void, goBack: () => void }) {
  return (
    <div className="h-full flex flex-col bg-white">
      {/* Header */}
      <div className="p-6 pb-2 bg-white flex items-center justify-between">
        <button onClick={goBack} className="p-2 -ml-2">
          <ArrowLeft size={24} />
        </button>
        <h1 className="text-2xl font-bold flex-1 text-center">Profile</h1>
        <div className="w-10" />
      </div>

      <div className="flex-1 overflow-y-auto px-6 py-8">
        {/* Profile Info */}
        <div className="flex flex-col items-center gap-6 mb-12">
          <div className="relative">
            <div className="w-32 h-32 rounded-[40px] border-4 border-white shadow-xl overflow-hidden shadow-rail-yellow/10">
              <img 
                src="https://img.icons8.com/color/144/child-skin-type-1.png" 
                alt="Profile" 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <button className="absolute -right-2 -bottom-2 w-12 h-12 bg-rail-yellow rounded-2xl flex items-center justify-center border-4 border-white shadow-lg active:scale-95 transition-transform">
              <Camera size={20} className="text-rail-dark" />
            </button>
          </div>
          <div className="text-center">
            <h2 className="text-3xl font-black text-rail-dark">Rahul Sharma</h2>
            <p className="text-gray-400 font-bold text-lg tracking-tight">rahul.sharma@gmail.com</p>
          </div>
          <div className="flex gap-4">
            <div className="bg-rail-yellow/10 px-6 py-3 rounded-2xl flex flex-col items-center">
              <span className="text-rail-yellow font-black text-xl">12</span>
              <span className="text-[10px] font-bold text-rail-yellow uppercase tracking-widest">Trips</span>
            </div>
            <div className="bg-blue-50 px-6 py-3 rounded-2xl flex flex-col items-center">
              <span className="text-blue-500 font-black text-xl">450</span>
              <span className="text-[10px] font-bold text-blue-500 uppercase tracking-widest">Points</span>
            </div>
          </div>
        </div>

        {/* Menu Items */}
        <div className="space-y-4">
          <ProfileMenu 
            icon={<User className="text-rail-yellow" size={24} />} 
            label="Personal Details" 
            badge="Verify"
          />
          <ProfileMenu 
            icon={<Bell className="text-blue-500" size={24} />} 
            label="Notification Settings" 
            onClick={() => navigate('notifications')}
          />
          <ProfileMenu 
            icon={<CreditCard className="text-green-500" size={24} />} 
            label="Payment Methods" 
          />
          <ProfileMenu 
            icon={<Shield className="text-purple-500" size={24} />} 
            label="Privacy & Security" 
          />
          <ProfileMenu 
            icon={<HelpCircle className="text-orange-500" size={24} />} 
            label="Help & Support" 
          />
          
          <button 
            onClick={() => window.location.reload()}
            className="w-full flex items-center justify-between p-6 bg-red-50 rounded-[32px] mt-8 group active:scale-98 transition-transform"
          >
            <div className="flex items-center gap-5">
              <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center shadow-sm">
                <LogOut className="text-red-500" size={24} />
              </div>
              <span className="font-black text-xl text-red-500">Logout</span>
            </div>
          </button>
        </div>
      </div>
    </div>
  );
}

function ProfileMenu({ icon, label, onClick, badge }: { icon: ReactNode, label: string, onClick?: () => void, badge?: string }) {
  return (
    <button 
      onClick={onClick}
      className="w-full flex items-center justify-between p-6 bg-white border border-gray-100 rounded-[32px] group active:scale-98 transition-transform"
    >
      <div className="flex items-center gap-5">
        <div className="w-14 h-14 bg-gray-50 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform">
          {icon}
        </div>
        <span className="font-bold text-xl text-rail-dark">{label}</span>
      </div>
      <div className="flex items-center gap-3">
        {badge && (
          <span className="bg-red-50 text-red-500 text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-widest">{badge}</span>
        )}
        <ChevronRight className="text-gray-300" size={20} />
      </div>
    </button>
  );
}
