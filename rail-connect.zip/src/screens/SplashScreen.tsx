import { motion } from 'motion/react';

export default function SplashScreen() {
  return (
    <div className="h-full flex flex-col items-center justify-center bg-white p-8">
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className="flex flex-col items-center gap-6"
      >
        <div className="w-32 h-32 bg-rail-yellow rounded-3xl flex items-center justify-center rotate-12 shadow-lg ring-8 ring-rail-yellow/20">
          <img 
            src="https://img.icons8.com/color/144/bullet-train.png" 
            alt="Logo" 
            className="w-20 h-20 -rotate-12"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className="text-center">
          <h1 className="text-4xl font-black tracking-tighter text-rail-dark">
            RAIL <span className="text-rail-yellow">CONNECT</span>
          </h1>
          <p className="text-sm font-medium text-gray-400 mt-2 tracking-widest uppercase italic">
            Smart Journey, Connected India
          </p>
        </div>
      </motion.div>
      
      <div className="absolute bottom-12 flex gap-2">
        {[0, 1, 2].map((i) => (
          <motion.div
            key={i}
            animate={{ scale: [1, 1.2, 1], opacity: [0.3, 1, 0.3] }}
            transition={{ repeat: Infinity, duration: 1.5, delay: i * 0.2 }}
            className="w-2 h-2 rounded-full bg-rail-yellow"
          />
        ))}
      </div>
    </div>
  );
}
