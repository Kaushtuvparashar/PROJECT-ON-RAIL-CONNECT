import { useState } from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, MapPin, ChevronRight, Calendar, User, QrCode, Download } from 'lucide-react';
import { MOCK_TICKETS } from '../constants';
import { Screen } from '../App';

export default function TicketsScreen({ navigate, goBack }: { navigate: (s: Screen) => void, goBack: () => void }) {
  const [tab, setTab] = useState<'upcoming' | 'completed'>('upcoming');
  const ticket = MOCK_TICKETS[0];

  return (
    <div className="h-full flex flex-col bg-[#FBFBFB]">
      {/* Header */}
      <div className="p-6 flex items-center justify-between bg-white relative">
        <button onClick={goBack} className="p-2 -ml-2">
          <ArrowLeft size={24} />
        </button>
        <h1 className="text-2xl font-bold flex-1 text-center">My Tickets</h1>
        <div className="w-10" />
      </div>

      <div className="px-6 py-8 flex-1 overflow-y-auto space-y-8">
        {/* Tabs */}
        <div className="bg-gray-100 p-1.5 rounded-[24px] flex gap-1 h-16">
          <button 
            onClick={() => setTab('upcoming')}
            className={`flex-1 rounded-[20px] font-bold text-lg transition-all ${tab === 'upcoming' ? 'bg-rail-yellow text-rail-dark shadow-sm' : 'text-gray-400'}`}
          >
            Upcoming
          </button>
          <button 
            onClick={() => setTab('completed')}
            className={`flex-1 rounded-[20px] font-bold text-lg transition-all ${tab === 'completed' ? 'bg-rail-yellow text-rail-dark shadow-sm' : 'text-gray-400'}`}
          >
            Completed
          </button>
        </div>

        {/* Ticket Card */}
        <div className="bg-white rounded-[40px] shadow-xl shadow-gray-200/50 border border-gray-50 overflow-hidden">
          {/* Top Section */}
          <div className="bg-[#002D24] p-6 text-white flex justify-between items-center">
            <span className="font-bold text-lg">{ticket.trainNumber} {ticket.trainName}</span>
            <div className="bg-[#22C55E] px-4 py-1.5 rounded-full">
              <span className="text-xs font-black uppercase tracking-tight">Running On Time</span>
            </div>
          </div>

          <div className="p-8 space-y-8">
            {/* Route */}
            <div className="flex justify-between items-center">
              <div className="flex flex-col">
                <span className="text-5xl font-black text-rail-dark">NDLS</span>
                <span className="text-sm font-bold text-gray-400">New Delhi</span>
              </div>
              <div className="flex-1 flex items-center justify-center relative px-4">
                <div className="h-[1px] bg-gray-100 w-full" />
                <ChevronRight className="bg-white px-2 text-gray-300" size={32} />
              </div>
              <div className="flex flex-col items-end">
                <span className="text-5xl font-black text-rail-dark">BCT</span>
                <span className="text-sm font-bold text-gray-400">Mumbai Central</span>
              </div>
            </div>

            {/* Date Time */}
            <div className="flex justify-between items-center text-gray-500 font-bold text-xl">
              <div className="flex items-center gap-2">
                <span>{ticket.date}</span>
              </div>
              <span>{ticket.time}</span>
            </div>

            <div className="h-[1px] bg-gray-50 bg-repeat-x" style={{ backgroundImage: 'linear-gradient(to right, #f3f4f6 50%, transparent 50%)', backgroundSize: '10px 1px' }} />

            {/* Info Grid */}
            <div className="grid grid-cols-2 gap-y-4">
              <div className="flex flex-col">
                <span className="text-gray-400 font-bold uppercase text-[10px] tracking-widest">PNR</span>
                <span className="text-rail-dark font-black text-xl tracking-tighter">{ticket.pnr}</span>
              </div>
              <div className="flex flex-col items-end">
                <span className="text-gray-400 font-bold uppercase text-[10px] tracking-widest">Passenger</span>
                <span className="text-rail-dark font-black text-xl">{ticket.passengerName}</span>
              </div>
              <div className="flex flex-col">
                <span className="text-gray-400 font-bold uppercase text-[10px] tracking-widest">Seat / Coach</span>
                <div className="flex items-center gap-2">
                  <img src="https://img.icons8.com/color/48/armchair.png" className="w-5 h-5 grayscale opacity-50" />
                  <span className="text-rail-dark font-black text-xl">{ticket.coach} - {ticket.seat}</span>
                </div>
              </div>
              <div className="flex flex-col items-end">
                <span className="text-gray-400 font-bold uppercase text-[10px] tracking-widest">Class</span>
                <span className="text-rail-dark font-black text-xl">{ticket.class}</span>
              </div>
            </div>

            {/* QR Code */}
            <div className="flex flex-col items-center gap-4 py-4">
              <div className="w-40 h-40 border-4 border-gray-50 rounded-3xl p-4 bg-white flex items-center justify-center">
                <img 
                  src="https://img.icons8.com/color/144/qr-code.png" 
                  className="w-full h-full opacity-80"
                  alt="QR"
                  referrerPolicy="no-referrer"
                />
              </div>
              <button className="flex items-center gap-2 text-gray-400 font-bold mt-2">
                Tap to download ticket
              </button>
            </div>

            {/* Footer Buttons */}
            <button 
              onClick={() => navigate('refund')}
              className="w-full bg-rail-yellow py-5 rounded-3xl text-xl font-bold text-rail-dark shadow-xl shadow-rail-yellow/20"
            >
              Cancel / Refund
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
