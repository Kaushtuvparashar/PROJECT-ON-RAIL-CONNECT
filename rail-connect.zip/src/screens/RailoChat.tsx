import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowLeft, Bell, Send, Mic, User } from 'lucide-react';
import { Message } from '../types';
import { getRailoResponse } from '../services/geminiService';

export default function RailoChat({ goBack }: { goBack: () => void }) {
  const [messages, setMessages] = useState<Message[]>([
    { id: '1', text: "Hi Rahul! 👋\nHow can I help you today?", sender: 'bot', timestamp: new Date() }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMsg: Message = { id: Date.now().toString(), text: input, sender: 'user', timestamp: new Date() };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    try {
      const railoReply = await getRailoResponse(messages, input);
      const botMsg: Message = { id: (Date.now() + 1).toString(), text: railoReply, sender: 'bot', timestamp: new Date() };
      setMessages(prev => [...prev, botMsg]);
    } catch (err) {
      console.error(err);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="h-full flex flex-col bg-white">
      {/* Header */}
      <div className="p-6 flex items-center justify-between border-b border-gray-100">
        <div className="flex items-center gap-4">
          <button onClick={goBack} className="p-2 -ml-2">
            <ArrowLeft size={24} />
          </button>
          <div className="flex flex-col">
            <h1 className="text-2xl font-bold text-rail-dark">AI Assistant - Railo</h1>
            <div className="flex items-center gap-1.5">
              <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
              <span className="text-xs font-bold text-green-500 uppercase tracking-widest">Online</span>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <button className="w-12 h-12 bg-gray-50 flex items-center justify-center rounded-2xl relative">
            <Bell size={24} className="text-gray-400" />
          </button>
          <div className="w-14 h-14 bg-gray-100 rounded-3xl p-1 flex items-center justify-center shadow-inner overflow-hidden border-2 border-gray-50">
            <img src="https://img.icons8.com/color/144/robot-2.png" className="w-full h-full object-contain" alt="Robot" referrerPolicy="no-referrer" />
          </div>
        </div>
      </div>

      {/* Messages */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-6 bg-gray-50/30">
        <AnimatePresence>
          {messages.map((msg) => (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 10, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`max-w-[85%] p-5 rounded-3xl text-lg font-medium shadow-sm ${
                msg.sender === 'user' 
                  ? 'bg-rail-yellow text-rail-dark rounded-tr-none' 
                  : 'bg-white text-rail-dark rounded-tl-none border border-gray-100'
              }`}>
                <div className="whitespace-pre-wrap">{msg.text}</div>
                <div className={`text-[10px] mt-2 font-bold uppercase tracking-widest opacity-40 ${msg.sender === 'user' ? 'text-right' : 'text-left'}`}>
                  {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </div>
              </div>
            </motion.div>
          ))}
          {isTyping && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex justify-start">
              <div className="bg-white p-4 rounded-3xl border border-gray-100 flex gap-1">
                <div className="w-2 h-2 rounded-full bg-rail-yellow animate-bounce [animation-delay:-0.3s]" />
                <div className="w-2 h-2 rounded-full bg-rail-yellow animate-bounce [animation-delay:-0.15s]" />
                <div className="w-2 h-2 rounded-full bg-rail-yellow animate-bounce" />
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Input */}
      <div className="p-6 safe-bottom">
        <div className="relative">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Type your message..."
            className="w-full bg-gray-50 py-6 pl-8 pr-24 rounded-[32px] text-xl font-medium focus:outline-none focus:ring-2 focus:ring-rail-yellow/20 transition-all border border-gray-100"
          />
          <div className="absolute right-4 top-1/2 -translate-y-1/2 flex items-center gap-2">
            <button className="p-4 text-rail-yellow">
              <Mic size={24} />
            </button>
            <button 
              onClick={handleSend}
              className={`p-4 rounded-[20px] transition-all ${input.trim() ? 'bg-rail-yellow text-rail-dark shadow-lg shadow-rail-yellow/30' : 'text-gray-300'}`}
            >
              <Send size={24} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
