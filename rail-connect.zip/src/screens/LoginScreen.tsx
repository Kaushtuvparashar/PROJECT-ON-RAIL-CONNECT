import { useState } from 'react';
import { motion } from 'motion/react';
import { Mail, Lock, ChevronDown, ArrowLeft } from 'lucide-react';

export default function LoginScreen({ onLogin, goBack }: { onLogin: () => void, goBack: () => void }) {
  return (
    <div className="h-full bg-white p-8 flex flex-col">
      <button onClick={goBack} className="mt-4 mb-8">
        <ArrowLeft size={24} />
      </button>

      <div className="flex flex-col gap-2 mb-12">
        <h1 className="text-5xl font-bold text-rail-dark">Login</h1>
        <h2 className="text-3xl font-bold text-rail-dark mt-4 leading-tight">Welcome Back!</h2>
        <p className="text-gray-400 text-lg font-medium">Login to continue your journey</p>
      </div>

      <div className="flex flex-col gap-6 flex-1">
        <button className="w-full bg-rail-yellow py-4 rounded-2xl flex items-center justify-center gap-3 font-bold text-lg shadow-lg shadow-rail-yellow/20">
          <img src="https://img.icons8.com/color/48/google-logo.png" className="w-6 h-6" alt="Google" referrerPolicy="no-referrer" />
          Continue with Google
        </button>

        <div className="flex items-center gap-4 py-2">
          <div className="h-[1px] bg-gray-100 flex-1" />
          <span className="text-gray-400 font-bold uppercase text-sm tracking-widest">or</span>
          <div className="h-[1px] bg-gray-100 flex-1" />
        </div>

        <div className="space-y-4">
          <div className="relative group">
            <Mail className="absolute left-6 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-rail-yellow transition-colors" size={24} />
            <input 
              type="text" 
              placeholder="Email or Mobile Number" 
              className="w-full bg-white border-2 border-gray-50 focus:border-rail-yellow outline-none py-5 pl-16 pr-6 rounded-2xl text-lg font-medium transition-all"
              defaultValue="rahul@gmail.com"
            />
          </div>

          <div className="relative group">
            <Lock className="absolute left-6 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-rail-yellow transition-colors" size={24} />
            <input 
              type="password" 
              placeholder="Password" 
              className="w-full bg-white border-2 border-gray-50 focus:border-rail-yellow outline-none py-5 pl-16 pr-14 rounded-2xl text-lg font-medium transition-all"
              defaultValue="********"
            />
            <ChevronDown className="absolute right-6 top-1/2 -translate-y-1/2 text-gray-400" size={24} />
          </div>

          <button className="text-rail-yellow font-bold text-right w-full text-lg">
            Forgot Password?
          </button>
        </div>
      </div>

      <div className="py-8 flex flex-col gap-8">
        <button
          onClick={onLogin}
          className="w-full bg-rail-yellow text-rail-dark py-5 rounded-2xl text-xl font-bold shadow-xl shadow-rail-yellow/30"
        >
          Login
        </button>
        
        <p className="text-center text-lg text-rail-dark font-medium opacity-80">
          Don't have an account? <span className="text-rail-yellow font-bold">Sign up</span>
        </p>
      </div>
    </div>
  );
}
