import { motion } from 'motion/react';
import { ArrowLeft, Clock, MapPin, ChevronRight, Share2, AlertCircle } from 'lucide-react';
import { MOCK_TRAINS } from '../constants';
import { Screen } from '../App';

export default function TrainDashboard({ navigate, goBack }: { navigate: (s: Screen) => void, goBack: () => void }) {
  const train = MOCK_TRAINS[0];

  return (
    <div className="h-full flex flex-col bg-[#FBFBFB]">
      {/* Header */}
      <div className="p-6 flex items-center justify-between bg-white">
        <button onClick={goBack} className="p-2 -ml-2">
          <ArrowLeft size={24} />
        </button>
        <h1 className="text-2xl font-bold flex-1 text-center">Train Dashboard</h1>
        <div className="w-10" />
      </div>

      <div className="flex-1 overflow-y-auto px-6 py-4 space-y-6">
        {/* Train Summary */}
        <div className="space-y-1">
          <div className="flex items-center gap-3">
            <h2 className="text-4xl font-black text-rail-dark tracking-tighter">{train.number} {train.name}</h2>
          </div>
          <div className="flex items-center gap-2 text-xl font-bold text-gray-500">
            <span>{train.from}</span>
            <ChevronRight className="opacity-30" size={20} />
            <span>{train.to}</span>
          </div>
          <div className="inline-flex items-center gap-2 bg-green-50 px-4 py-2 rounded-full mt-2">
            <div className="w-2 h-2 rounded-full bg-green-500" />
            <span className="text-green-600 font-bold tracking-tight">Running On Time</span>
          </div>
        </div>

        {/* Speedometer Widget */}
        <div className="bg-white rounded-[40px] p-8 shadow-sm border border-gray-50 flex flex-col items-center relative overflow-hidden">
          <div className="w-56 h-32 relative overflow-hidden">
            <svg viewBox="0 0 100 50" className="w-full h-full transform translate-y-2">
              <path 
                d="M 10 45 A 40 40 0 0 1 90 45" 
                fill="none" 
                stroke="#F3F4F6" 
                strokeWidth="8" 
                strokeLinecap="round" 
              />
              <path 
                d="M 10 45 A 40 40 0 0 1 60 10" 
                fill="none" 
                stroke="#FFC107" 
                strokeWidth="8" 
                strokeLinecap="round"
                className="transition-all duration-1000"
              />
            </svg>
            <div className="absolute inset-x-0 bottom-2 flex flex-col items-center">
              <span className="text-6xl font-black text-rail-dark -mb-2">82</span>
              <span className="text-base font-bold text-gray-400">km/h</span>
            </div>
          </div>
          <span className="text-gray-400 font-bold mt-4 uppercase tracking-widest text-[10px]">Live Speed</span>
        </div>

        {/* Next Station Info */}
        <div 
          onClick={() => navigate('tracking')}
          className="bg-white rounded-[32px] p-6 shadow-sm border border-gray-100 space-y-4 cursor-pointer active:scale-98 transition-transform"
        >
          <div className="flex items-center justify-between">
            <span className="text-gray-400 font-bold text-xs uppercase tracking-widest">Next Station</span>
          </div>
          <div className="flex justify-between items-end">
            <div>
              <h3 className="text-3xl font-black text-rail-dark">Agra Cantt</h3>
              <div className="flex items-center gap-6 mt-4">
                <div className="flex flex-col">
                  <span className="text-gray-400 font-bold text-[10px] uppercase">Arrival</span>
                  <span className="font-black text-rail-dark">11:32 AM</span>
                </div>
                <div className="flex flex-col">
                  <span className="text-gray-400 font-bold text-[10px] uppercase">Platform</span>
                  <span className="font-black text-rail-dark">2</span>
                </div>
              </div>
            </div>
            <div className="bg-green-50 p-4 rounded-3xl flex flex-col items-center gap-1 mb-1">
              <Clock className="text-green-500" size={24} />
              <span className="text-green-600 font-black text-lg leading-none">12 min</span>
            </div>
          </div>
        </div>

        {/* Coach Position */}
        <div className="bg-white rounded-[32px] p-6 shadow-sm border border-gray-100 space-y-4">
          <span className="text-gray-400 font-bold text-xs uppercase tracking-widest">Coach Position</span>
          <div className="flex gap-2 overflow-x-auto pb-2 -mx-2 px-2 scrollbar-none">
            {['Eng', 'B1', 'B2', 'B3', 'B5', 'B6', 'B7', 'E1'].map((coach) => (
              <div 
                key={coach} 
                className={`min-w-[60px] h-12 flex items-center justify-center rounded-xl font-bold text-sm ${coach === 'B2' ? 'bg-rail-yellow text-rail-dark' : 'bg-gray-100 text-gray-400'}`}
              >
                {coach}
              </div>
            ))}
          </div>
        </div>

        {/* Journey Progress */}
        <div className="bg-white rounded-[32px] p-6 shadow-sm border border-gray-100 space-y-4">
          <div className="flex justify-between items-center bg-white">
            <span className="text-gray-400 font-bold text-xs uppercase tracking-widest">Journey Progress</span>
          </div>
          <div className="space-y-4">
            <div className="relative h-2 bg-gray-100 rounded-full overflow-hidden">
              <div className="absolute left-0 top-0 h-full w-1/3 bg-rail-yellow rounded-full" />
              <div className="absolute left-[33%] top-1/2 -translate-y-1/2 w-4 h-4 bg-white border-2 border-rail-yellow rounded-full -translate-x-1/2" />
            </div>
            <div className="flex justify-between font-black text-gray-400 text-sm">
              <span className="text-rail-dark">450 KM</span>
              <span>/ 1384 KM</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
