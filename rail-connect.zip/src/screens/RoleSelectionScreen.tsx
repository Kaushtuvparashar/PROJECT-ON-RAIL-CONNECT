import { motion } from 'motion/react';
import { Role } from '../types';

const ROLES = [
  { id: 'passenger', title: 'Passenger', subtitle: 'Book, Travel & Explore', icon: 'https://img.icons8.com/color/144/person-female.png' },
  { id: 'attendant', title: 'Attendant', subtitle: 'Manage & Assist', icon: 'https://img.icons8.com/color/144/policeman.png' },
  { id: 'vendor', title: 'Vendor', subtitle: 'Food & Services', icon: 'https://img.icons8.com/color/144/shop.png' },
  { id: 'admin', title: 'Admin', subtitle: 'Monitor & Manage', icon: 'https://img.icons8.com/color/144/admin-settings-male.png' }
];

export default function RoleSelectionScreen({ onSelect }: { onSelect: (role: Role) => void }) {
  return (
    <div className="h-full bg-white p-8 overflow-y-auto">
      <div className="flex flex-col gap-2 mt-12 mb-10">
        <h1 className="text-4xl font-bold text-rail-dark">Select Your Role</h1>
        <p className="text-gray-500 font-medium">Choose your role to continue</p>
      </div>

      <div className="grid grid-cols-2 gap-4">
        {ROLES.map((role, i) => (
          <motion.button
            key={role.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            onClick={() => onSelect(role.id as Role)}
            className="flex flex-col items-center gap-4 p-6 bg-white border border-gray-100 rounded-[32px] shadow-sm hover:shadow-md transition-shadow active:scale-95"
          >
            <div className="w-20 h-20 flex items-center justify-center p-2 bg-gray-50 rounded-2xl">
              <img src={role.icon} alt={role.title} className="w-full h-full object-contain" referrerPolicy="no-referrer" />
            </div>
            <div className="text-center">
              <h3 className="font-bold text-lg text-rail-dark">{role.title}</h3>
              <p className="text-xs text-gray-400 font-medium">{role.subtitle}</p>
            </div>
          </motion.button>
        ))}
      </div>
    </div>
  );
}
