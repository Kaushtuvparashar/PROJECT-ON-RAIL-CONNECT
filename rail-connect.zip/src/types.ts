export type Role = 'passenger' | 'attendant' | 'vendor' | 'admin';

export interface Train {
  id: string;
  number: string;
  name: string;
  from: string;
  fromCode: string;
  to: string;
  toCode: string;
  departureTime: string;
  arrivalTime: string;
  duration: string;
  status: 'on-time' | 'delayed' | 'cancelled';
  delay?: string;
  platform?: string;
  speed?: number;
  progress?: number;
  totalDistance?: number;
  nextStation?: string;
}

export interface Ticket {
  id: string;
  pnr: string;
  trainNumber: string;
  trainName: string;
  from: string;
  fromCode: string;
  to: string;
  toCode: string;
  date: string;
  time: string;
  passengerName: string;
  seat: string;
  coach: string;
  class: string;
  status: 'upcoming' | 'completed';
  price: number;
}

export interface FoodItem {
  id: string;
  name: string;
  price: number;
  rating: number;
  image: string;
  type: 'veg' | 'non-veg';
  category: 'snacks' | 'meals' | 'drinks';
}

export interface Notification {
  id: string;
  title: string;
  message: string;
  time: string;
  type: 'alert' | 'offer' | 'update';
  icon: string;
}

export interface ServiceRequest {
  id: string;
  seat: string;
  passengerName: string;
  type: 'cleaning' | 'water' | 'toilet' | 'emergency';
  time: string;
  status: 'pending' | 'accepted' | 'completed';
}

export interface Message {
  id: string;
  text: string;
  sender: 'user' | 'bot';
  timestamp: Date;
}
