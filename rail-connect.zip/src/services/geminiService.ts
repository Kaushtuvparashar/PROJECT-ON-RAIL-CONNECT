import { GoogleGenAI } from "@google/genai";
import { Message } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function getRailoResponse(history: Message[], userInput: string): Promise<string> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: [
        {
          role: "user",
          parts: [{ text: `
            You are Railo, a helpful AI train travel buddy for the "Rail Connect" app.
            User's current journey: NDLS to BCT (Rajdhani Express).
            Current station: Heading to Agra Cantt.
            Arriving at Agra Cantt at 11:32 AM.
            User info: Rahul Sharma, Seat B2-45.
            
            Be friendly, concise, and helpful. Use emojis like 🚂, 👋, ✨.
            Answer questions about train status, food, cleaning services, or general travel advice.
          `}]
        },
        ...history.map(m => ({
          role: m.sender === 'user' ? 'user' : 'model',
          parts: [{ text: m.text }]
        })),
        { role: 'user', parts: [{ text: userInput }] }
      ],
    });
    
    return response.text || "I'm sorry, I couldn't process that. How else can I help your journey? 🚂";
  } catch (error) {
    console.error("Railo AI error:", error);
    return "The rails are a bit noisy right now! Please try again in a moment. 🚂";
  }
}
