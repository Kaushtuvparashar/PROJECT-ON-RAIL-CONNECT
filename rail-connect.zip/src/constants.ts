import { Train, Ticket, FoodItem, Notification, ServiceRequest } from './types';

export const MOCK_TRAINS: Train[] = [
  {
    id: '1',
    number: '12951',
    name: 'Rajdhani Express',
    from: 'New Delhi',
    fromCode: 'NDLS',
    to: 'Mumbai Central',
    toCode: 'BCT',
    departureTime: '11:30 AM',
    arrivalTime: '08:30 AM',
    duration: '21h 00m',
    status: 'on-time',
    speed: 82,
    progress: 450,
    totalDistance: 1384,
    nextStation: 'Agra Cantt',
    platform: '2'
  },
  {
    id: '2',
    number: '12002',
    name: 'Shatabdi Express',
    from: 'New Delhi',
    fromCode: 'NDLS',
    to: 'Bhopal',
    toCode: 'BPL',
    departureTime: '06:00 AM',
    arrivalTime: '02:00 PM',
    duration: '08h 00m',
    status: 'on-time'
  },
  {
    id: '3',
    number: '12627',
    name: 'Karnataka Sampark',
    from: 'Delhi',
    fromCode: 'KSR',
    to: 'Bangalore',
    toCode: 'SBC',
    departureTime: '08:00 PM',
    arrivalTime: '06:00 AM',
    duration: '34h 00m',
    status: 'delayed',
    delay: '30m'
  }
];

export const MOCK_TICKETS: Ticket[] = [
  {
    id: 't1',
    pnr: '6723456789',
    trainNumber: '12951',
    trainName: 'Rajdhani Express',
    from: 'New Delhi',
    fromCode: 'NDLS',
    to: 'Mumbai Central',
    toCode: 'BCT',
    date: '21 May 2025',
    time: '11:30 AM',
    passengerName: 'Rahul Sharma',
    seat: '45',
    coach: 'B2',
    class: '3A',
    status: 'upcoming',
    price: 1230
  }
];

export const FOOD_MENU: FoodItem[] = [
  {
    id: 'f1',
    name: 'Veg Biryani',
    price: 150,
    rating: 4.5,
    type: 'veg',
    category: 'meals',
    image: 'https://images.unsplash.com/photo-1563379091339-03b21bc4a4f8?q=80&w=400'
  },
  {
    id: 'f2',
    name: 'Paneer Butter Masala',
    price: 180,
    rating: 4.6,
    type: 'veg',
    category: 'meals',
    image: 'https://images.unsplash.com/photo-1631452180519-c014fe946bc7?q=80&w=400'
  },
  {
    id: 'f3',
    name: 'Masala Dosa',
    price: 120,
    rating: 4.3,
    type: 'veg',
    category: 'snacks',
    image: 'https://images.unsplash.com/photo-1589301760014-d929f3979dbc?q=80&w=400'
  }
];

export const NOTIFICATIONS: Notification[] = [
  {
    id: 'n1',
    title: 'Agra Cantt in 12 min',
    message: 'Got ready for arrival',
    time: '10:20 AM',
    type: 'alert',
    icon: 'bell'
  },
  {
    id: 'n2',
    title: 'Food Order Confirmed',
    message: 'Veg Biryani is preparing',
    time: '10:18 AM',
    type: 'update',
    icon: 'utensils'
  },
  {
    id: 'n3',
    title: 'Cleaning Completed',
    message: 'Your seat B2 - 45 is clean',
    time: '09:45 AM',
    type: 'update',
    icon: 'check-circle'
  }
];

export const SERVICE_REQUESTS: ServiceRequest[] = [
  {
    id: 's1',
    seat: 'B2 - 45',
    passengerName: 'Rahul Sharma',
    type: 'cleaning',
    time: '2 min ago',
    status: 'pending'
  },
  {
    id: 's2',
    seat: 'B1 - 32',
    passengerName: 'Priya Singh',
    type: 'water',
    time: '3 min ago',
    status: 'pending'
  },
  {
    id: 's3',
    seat: 'S8 - 18',
    passengerName: 'Amit Kumar',
    type: 'cleaning',
    time: '5 min ago',
    status: 'completed'
  }
];
